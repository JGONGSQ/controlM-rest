BASE_URL = "https://localhost:8443/automation-api"
USERNAME = "workbench"
PASSWORD = "workbench"

CTM = "workbench"
TEST_FOLDER = "workbench_folder"